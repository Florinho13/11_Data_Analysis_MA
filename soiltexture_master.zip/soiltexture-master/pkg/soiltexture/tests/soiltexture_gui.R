
library( "soiltexture" )

#   Call the text graphical user interface

soiltexture_gui()

#   ... and follow the instructions indicated to you!
