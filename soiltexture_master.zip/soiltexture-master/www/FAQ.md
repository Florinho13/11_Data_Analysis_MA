soiltexture: FAQ
================

_This page is under construction. Please come back later_

Test
----


```r
library( "soiltexture" ) 
```

```
## soiltexture 1.3.0 (svn revision: 122:125M). For help type: help(pack='soiltexture')
```

```r
TT.plot()
```

![plot of chunk test](figure/test-1.png) 
