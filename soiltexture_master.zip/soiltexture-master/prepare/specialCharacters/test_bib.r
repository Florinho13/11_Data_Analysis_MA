
setwd( "F:/Users/julien/Documents/_r-packages/soiltexture/pkg/soiltexture/vignettes" )

tools::showNonASCIIfile("soiltexture_vignette.bib")

# 17:   title = {Soil -- Korngr<f6>\ss endreieck -- Particle Size Diagram},
# 116:   author = {{dos Santos}, Humberto Gon<e7>alves, et al.},
# 117:   title = {Sistema Brasileiro de Classifica<e7>\~{a}o de Solos},
# 199:   volume = {18 (hors s<e9>rie)},
# 234:   title = {Manual de descri<e7><e3>o e coleta de solo no campo. 3a ed. Campinas},
# 235:   institution = {Sociedade Brasileira de Ci<ea>ncia do solo},
# 242:   author = {Linn<e9>a Lidberg},
# 243:   title = {Texturbest<e4>mning genom f<e4>lt-, pipett- och hydrometermetoder},
# 244:   school = {SLU -- Institutionen f<f6>r skoglig markl<e4>ra (Department of Forest Soils)},
# 284:   title = {Variabilit<e9> spatiale et d<e9>terminismes agro<96>p<e9>dologiques du devenir
# 285:    d<92>un herbicide dans l<92>horizon de surface -- Application au cas de
# 299:   author = {A. Nemes and J.H.M. W<f6>sten and A. Lilly and J.H. {Oude Voshaar}},
# 361:   title = {Phototh<e8>que -- Etude d'un sol -- Triangle des textures GEPPA},
