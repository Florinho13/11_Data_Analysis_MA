lang.par2 <- data.frame( 
    "lang"  = "pl", 
    "CLAY"  = "\"Il\"", 
    "SILT"  = "\"Pyl\"", 
    "SAND"  = "\"Piasek\"", 
    "TT"    = "\"Trojkat Fereta\"", 
    stringsAsFactors    = FALSE  
)   


